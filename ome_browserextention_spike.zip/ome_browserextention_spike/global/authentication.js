(function () {
    console.log("Start Authentication Check");

    var port = chrome.runtime.connect({
        name: "checkUser"
    });
    port.postMessage({
        user: "getUserdata"
    });

    console.log("Viewhighlights page connected");

    document.getElementById("saveAllNotes").addEventListener("click", saveAllNotes, false);
    // document.getElementById("home-tab").addEventListener('click', getNotesForUser);
    document.getElementById("userLogin").classList.add("dis-none");

    var saveData = [];

    chrome.tabs.query({
        active: true,
        // Select active tabs
        lastFocusedWindow: true // In the current window
    }, function (array_of_Tabs) {
        // Since there can only be one active tab in one active window,
        //  the array has only one element
        var tab = array_of_Tabs[0];
        // console.log(tab.url);
        // Example:
        var url = tab.url;
        chrome.storage.local.set({
            taburl: url
        });
        //display Add Notes
        chrome.storage.sync.get("displayHighlights", function (data) {
            if (data.displayHighlights === null) {
                document.getElementById("loadHighlights").classList.add("dis-none");
            } else {

                let filterData = data.displayHighlights.filter(element => {
                    if (element.url === url) {
                        return element;
                    }
                });
                if (filterData.length > 0) {
                    document.getElementById("loadHighlights").classList.remove("dis-none");
                    document.getElementById("toggleSave").classList.remove("dis-none");
                    // console.log(filterData);
                    displayHighLights(filterData);
                    saveData = filterData;
                } else {
                    document.getElementById("loadHighlights").classList.add("dis-none");
                }

            }
        });
        chrome.storage.sync.get("userData", function (data) {
            if (data.userData) {
                let div = document.createElement("div");
                div.innerHTML = "User id:" + data.userData.userid;
                div.setAttribute("id", "userName");
                document.getElementById("userLogin").classList.add("dis-none");
                document.getElementById("notesDiv").classList.remove("dis-none");
                document.getElementById("goToSignIn").classList.add("dis-none");
                document.getElementById("showUser").appendChild(div);
                document.getElementById("logout").classList.remove("dis-none");
            } else {}
        });

        //get from database
        updateNotes(url);
    });


    function updateNotes(url) {
        chrome.storage.sync.get(null, function (items) {

            console.log(items["userData"]);
            if (items["userData"] !== null) {

                getValue(function (items) {
                    let filterNotesByUrl = items["userNotes"].usernotes.filter(element => {
                        if (element.url === url) {
                            return element;
                        }
                    });
                    displayNotesByUrl(filterNotesByUrl);
                    var port = chrome.runtime.connect({
                        name: "displayOnPage"
                    });
                    port.postMessage({
                        displayOnPage: filterNotesByUrl
                    });

                });
            } else {
                displayNotesByUrl();
            }

        });
    }

    function getValue(callback) {
        chrome.storage.local.get("userNotes", callback);
    }


    var loadHighlights = document.getElementById("addNotes");

    function displayHighLights(msg) {
        if (msg.length > 1) {
            msg.forEach(element => {
                if (!loadHighlights.contains(document.getElementById(element.id))) {
                    insertNode(element);
                } else {
                    return;
                }
            });
        } else {
            insertNode(msg[0]);
        }
    }

    function insertNode(elm) {
        let div = document.createElement("li");
        let save = document.createElement("button");
        save.innerHTML = "save note";
        div.setAttribute("class", "notes");
        div.innerHTML = elm.selection;
        div.setAttribute("id", elm.id);
        loadHighlights.prepend(div);
    }

    function saveAllNotes(e) {
        e.preventDefault();
        // Set storage properties
        chrome.storage.sync.get("userData", function (data) {
            // Default to empty array
            // console.log(data.userData);
            // console.log(saveData);
            if (data.userData) {
                let note = {
                    userId: data.userData.userid,
                    token: data.userData.access_token.token,
                    noteRemark: document.getElementById("noteRemark").value,
                    noteData: JSON.stringify(saveData),
                    noteId: saveData[0].id,
                    url: saveData[0].url
                };
                console.log(note);
                let saveUserNotes = httpCall("http://192.168.0.6:8012/api/createnotes", {
                    ...note
                }).done(function (data) {
                    // console.log(data);

                    if (data) {
                        var port = chrome.runtime.connect({
                            name: "cleanNotes"
                        });
                        port.postMessage({
                            cleanNotes: saveData
                        });
                    }
                });
                saveUserNotes.then(saveData => {
                    loadHighlights.innerHTML = "";
                    loadHighlights.innerHTML = saveData.message;
                    document.getElementById("toggleSave").classList.add("dis-none");
                    setTimeout(function () {
                        loadHighlights.innerHTML = "";
                        document.getElementById("loadHighlights").classList.add("dis-none");
                    }, 2000);



                    let getNotesByUrl = httpCall("http://192.168.0.6:8012/api/getnotesbyuser", {
                        token: data.userData.access_token.token,
                        userid: data.userData.userid
                    }).done(function (getNotes) {
                        console.log(getNotes)
                        if (getNotes) {
                            var port = chrome.runtime.connect({
                                name: "getUserNotes"
                            });
                            port.postMessage({
                                userNotes: getNotes
                            });
                        }
                    })

                    getNotesByUrl.then((data) => {
                        chrome.storage.local.get('taburl', function (urldata) {
                            updateNotes(urldata.taburl);
                        });
                    });

                });
            } else {
                alert("Please sign in to save notes");
            }
        });
    }

    //authentication.js

    document.getElementById('noteCancel').addEventListener('click', noteCancel);
    document.getElementById('userSignIn').addEventListener('click', userSignIn);
    document.getElementById('goToSignIn').addEventListener('click', goToLogin);
    document.getElementById('logout').addEventListener('click', logout);

    // document.getElementById('gotoRegister').addEventListener('click', gotoRegister);
    // document.getElementById('registerUser').addEventListener('click', registerUser);

    function userSignIn(e) {


        e.preventDefault();
        var obj = {};
        obj.email = $("#emailUser").val();
        obj.password = $("#passUser").val();
        var url = chrome.storage.local.get('taburl', function (data) {
            return data
        });
        let userlogged = httpCall("http://192.168.0.6:8012/api/authenticate", {
            email: obj.email,
            password: obj.password
        }).done();
        userlogged.then((data) => {
            console.log(data);
            if (data.status !== 200) {
                $("#userLogin").after("<span id=error>" + data.message + "</span>")
                setTimeout(function () {
                    $("#error").remove();
                }, 2000);
            } else {
                var port = chrome.runtime.connect({
                    name: "authenTicateUser"
                });
                port.postMessage({
                    userData: data
                });
                let div = document.createElement('div');
                div.innerHTML = "User id:" + data.userid;
                div.setAttribute("id", "userName");
                document.getElementById("userLogin").classList.add("dis-none");
                document.getElementById("notesDiv").classList.remove("dis-none");
                document.getElementById("goToSignIn").classList.add("dis-none");
                document.getElementById("showUser").appendChild(div);
                document.getElementById("logout").classList.remove("dis-none");


                let getNotesByUrl = httpCall("http://192.168.0.6:8012/api/getnotesbyuser", {
                    token: data.access_token.token,
                    userid: data.userid
                }).done(function (getNotes) {
                    if (getNotes) {
                        var port = chrome.runtime.connect({
                            name: "getUserNotes"
                        });
                        port.postMessage({
                            userNotes: getNotes
                        });
                    }
                })

                getNotesByUrl.then((data) => {
                    chrome.storage.local.get('taburl', function (urldata) {
                        displayNotesAtLogin(urldata.taburl, data);
                    });
                });
            }
        })



    }

    function noteCancel(e) {
        e.preventDefault();
        document.getElementById("userLogin").classList.add("dis-none");
        document.getElementById("notesDiv").classList.remove("dis-none");
        document.getElementById("goToSignIn").classList.remove("dis-none");
    }





    function goToLogin() {
        document.getElementById("goToSignIn").classList.add("dis-none");
        document.getElementById('userLogin').classList.remove('dis-none');
        document.getElementById('notesDiv').classList.add('dis-none');
    }


    function logout(e) {
        e.preventDefault();
        var port = chrome.runtime.connect({
            name: "logoutUser"
        });
        port.postMessage({
            userData: null,
            userNotes: null
        });
        document.getElementById("logout").classList.add("dis-none");
        document.getElementById("goToSignIn").classList.remove("dis-none");
        document.getElementById("userName").remove();
        document.getElementById("home").innerHTML = "";
        document.getElementById("home").innerHTML = "Please Signin to view notes";

    }

    function displayNotesAtLogin(url, getNotes) {
        let filterNotesByUrl = getNotes.usernotes.filter((element) => {
            if (element.url === url) {
                return element;
            }
        });
        displayNotesByUrl(filterNotesByUrl);
        var port = chrome.runtime.connect({
            name: "displayOnPage"
        });
        port.postMessage({
            displayOnPage: filterNotesByUrl
        });


    }
    var loaded = false;

    function displayNotesByUrl(data) {
        let loadNotes = document.getElementById("home");
        loadNotes.innerHTML = "";
        if (data) {
            dataInnerDiv = true;
            data.forEach((note, index) => {

                let mainNote = document.createElement('div');
                mainNote.classList.add("mainNote");
                let span = "<div class='d-flex justify-content-end index-name'><span class=mr-1>" + (index + 1) + ".</span><span>" + note.noteRemark + "</span><div>";
                mainNote.innerHTML = span;
                const noteData = JSON.parse(note.noteData);
                noteData.forEach((innerNote) => {
                    console.log("From authentication:" + innerNote);
                    let innerDiv = document.createElement("div");
                    innerDiv.classList.add("innerNote");
                    innerDiv.setAttribute('id', innerNote.id);
                    innerDiv.innerHTML = innerNote.selection;
                    mainNote.appendChild(innerDiv)
                })
                loadNotes.appendChild(mainNote);

            })
            loaded = true;
        } else {
            loadNotes.innerHTML = "No Notes";
            dataInnerDiv = false;
        }
    }


    // scroll to id
    $(document).on('click', '.mainNote .innerNote', function () {
        let id = $(this).attr('id');
        var port = chrome.runtime.connect({
            name: "scrollToId"
        });
        port.postMessage({
            scrollToId: id
        });
    })



    function httpCall(url, postData = {}, asyncCall = true, headers = {}, type = "POST") {
        return $.ajax({
            type: type,
            url: url,
            headers: headers,
            async: asyncCall,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(postData)
        });
    }

    // setInterval(function(){
    //     console.log("sendmessage");
    //     sendMessage();
    // }, 3000)
    // function sendMessage(){
    //     var port = chrome.runtime.connect({
    //         name: "getUrlTime"
    //     });
    //     port.postMessage({
    //         getUrlTime: "catch"
    //     });
    // }
})();