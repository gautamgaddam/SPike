window.browser = (function () {
    return window.msBrowser ||
        window.browser ||
        window.chrome;
})();
console.log("Spike content script started");

var spikeStatus;

var selectionChangeTimer = null;
var created = false;


getValue(function (items) {
 if(items["userNotes"]!== null){
    let filterNotesByUrl = items["userNotes"].usernotes.filter(element => {

        if (element.url === window.location.href) {
            return element;
        }
    });
    highlightNotes(filterNotesByUrl);
}
else{
    return false;
}
});


function getValue(callback) {
    chrome.storage.local.get(null, callback);
}


chrome.extension.onMessage.addListener(function (msg, sender, sendResponse) {

    if (msg.displayMessage) {
        console.log(msg.displayMessage.displayOnPage)
        highlightNotes(msg.displayMessage.displayOnPage);

    } else if (msg.scrollToId) {
        let scroll = msg.scrollToId.scrollToId;
        try {
            scrollIt(
                document.querySelector('#' + scroll + ''),
                300,
                'easeOutQuad',
                () => console.log(`Just finished scrolling to ${window.pageYOffset}px`)
            );
        } catch (error) {
            console.log("Cannot find the element");
        }

    }else if(msg.message.getUrlTime){
        console.log(msg);
        console.log(window.location.href)
    }
    
    else {
        console.log("No Notes in this page");
    }
})

function highlightNotes(data) {
    let noteData = data.map((elem) => JSON.parse(elem.noteData))
    noteData.forEach((note) => {
        note.forEach((innerNote) => {
            createHighlight(innerNote.range, innerNote.id, innerNote.className);
        });
    })
}


document.addEventListener("selectionchange", handleSelectionChange, false);
var redrawTimer = null;
window.addEventListener("scroll", redrawSelectionBoxes, false);
window.addEventListener("resize", redrawSelectionBoxes, false);

function handleSelectionChange() {
    var selectionString = window.getSelection().toString();
    // console.log(spikeStatus);
    if (selectionString) {
        if (selectionString[0].length > 0) {
            clearTimeout(selectionChangeTimer);
            selectionChangeTimer = setTimeout(drawSelectionBoxes, 300);
        }

    } else {

        return;
    }
}


// I debounce the redrawing of the selection boxes.
function redrawSelectionBoxes(event) {
    // if (spikeStatus) {
    clearTimeout(redrawTimer);
    redrawTimer = setTimeout(drawSelectionBoxes, 100);
    // }
    // else {
    //     return;
    // }
}


// I clear the fixed-position selection boxes that outline the current selection
// within the document.
function clearCurrentSelectionBoxes() {
    var nodes = document.querySelectorAll("div.bounding-rect, div.segment-rect, div.text-fields");
    for (var i = 0; i < nodes.length; i++) {
        nodes[i].parentNode.removeChild(nodes[i]);
    }

}


// I draw the rectangles around the various Selection ranges.
function drawSelectionBoxes() {
    clearCurrentSelectionBoxes();
    var selection = window.getSelection();
    // If the selection doesn't represent a range, let's ignore it.
    // --
    // NOTE: I'd rather use the "type" property (None, Range, Caret); however, in
    // my testing, this does not appear to be supported in IE. As such, we'll use
    // the rangeCount and test the range dimensions).


    if (!selection.toString().length > 0) {
        clearCurrentSelectionBoxes();
        return;
    } else {
        // Technically, a selection can have multiple ranges, as defined in the
        // "Selection.rangeCount" property; but, for the most part, we are only going
        // to deal with the first (and often only) selection range.
        var range = selection.getRangeAt(0);
        var rect = range.getBoundingClientRect();

        // Check to make sure the selection dimensions aren't zero.
        if (rect.width && rect.height) {

            var outline = document.createElement("div");
            outline.classList.add("bounding-rect");
            outline.style.top = (rect.top + "px");
            outline.style.left = (rect.left + "px");
            outline.style.width = (rect.width + "px");
            outline.style.height = (rect.height + "px");
            outline.style.position = "fixed";
            outline.style.zIndex = 20;

            (selection.toString().length > 0) ? outline.appendChild(createDiv()): clearCurrentSelectionBoxes();
            document.body.appendChild(outline);

        }

        var rects = range.getClientRects();
        for (var i = 0; i < rects.length; i++) {

            var rect = rects[i];
            // Check to make sure the selection dimensions aren't zero.
            if (rect.width && rect.height) {

                var outline = document.createElement("div");
                outline.classList.add("segment-rect");
                outline.style.top = (rect.top + "px");
                outline.style.left = (rect.left + "px");
                outline.style.width = (rect.width + "px");
                outline.style.height = (rect.height + "px");
                outline.style.border = "1px dotted  blue";
                outline.style.position = "fixed";
                outline.style.zIndex = 13;
                document.body.appendChild(outline);
            }


        }
    }
}


function createDiv() {
    var container = document.createElement('div');
    container.classList.add('text-fields');
    var saveButton = document.createElement('input');
    var cancelButton = document.createElement('input');
    saveButton.setAttribute('type', 'button');
    saveButton.setAttribute('value', 'Add');
    cancelButton.setAttribute('type', 'button');
    cancelButton.setAttribute('value', 'cancel');
    saveButton.style.marginLeft = '10px';
    saveButton.style.marginRight = '10px';
    saveButton.style.width = 'max-content';
    cancelButton.style.width = 'max-content';
    container.style.display = 'flex';

    container.appendChild(saveButton);
    container.appendChild(cancelButton);
    container.style.zIndex = 20;
    saveButton.addEventListener('click', saveCurrentSelections, false);
    cancelButton.addEventListener('click', cancelAllSelections, false);
    return container;


}

function saveCurrentSelections() {
    const highlights = addHighlight();
    console.log(highlights);

    console.log(isValidChromeRuntime());
    if (isValidChromeRuntime()) {
        var port = chrome.runtime.connect({
            name: "pushHighlight"
        });
        port.postMessage({
            displayHighlights: highlights
        });
    } else {
        // Fall back to contentscript-only behavior
    }

    clearCurrentSelectionBoxes();
}

function cancelAllSelections() {
    clearCurrentSelectionBoxes();
}

function isValidChromeRuntime() {
    // It turns out that chrome.runtime.getManifest() returns undefined when the
    // runtime has been reloaded.
    // Note: If this detection method ever fails, try to send a message using
    // chrome.runtime.sendMessage. It will throw an error upon failure.

    try {
        return chrome.runtime && !!chrome.runtime.getManifest();
    } catch (error) {
        console.log(error);
        alert("Please reload the page");
    }

}



function addHighlight() {
    var id = null;
    var className = null;
    var obj = {};
    var notes = [];
    var range = window.getSelection().getRangeAt(0);

    obj.selection = window.getSelection().toString().trim();
    if (obj.selection.length > 0) {

        className = _stringUtils.createUUID({
            beginWithLetter: true
        });
        id = _stringUtils.createUUID({
            beginWithLetter: true
        });
        var newRange = _xpath.createXPathRangeFromRange(range);

        createHighlight(newRange, id, className);



        obj.range = newRange;
        obj.id = id;
        obj.className = className;
        obj.date = new Date();
        obj.url = window.location.href;
        notes.push(obj);
        return notes;
    } else {
        alert("Please select text");
        return;
    }

}










var _contentScript = {
    highlightClassName: "apply-bg"
};


function createHighlight(xpathRange, id, className) {
    "use strict";
    var range;

    // this is likely to cause exception when the underlying DOM has changed
    try {
        range = _xpath.createRangeFromXPathRange(xpathRange);
    } catch (err) {
        console.log("Exception parsing xpath range: " + err.message);
        return null;

    }

    if (!range) {
        console.log("error parsing xpathRange: " + xpathRange);
        return null;
    }
    return create(range, id, [
        _contentScript.highlightClassName,
        className
    ]);
}







//create span and wrap

function create(range, id, className) {
    "use strict";

    // highlights are wrapped in one or more spans
    var span = document.createElement("mark");
    // span.style.background = 'gray';
    span.className = (className instanceof Array ? className.join(" ") : className);

    // each node has a .nextElement property, for following the linked list
    var record = {
        firstSpan: null,
        lastSpan: null
    };

    _doCreate(range, record, function () {
        // wrapper creator
        var newSpan = span.cloneNode(false);

        // link up
        if (!record.firstSpan) {
            record.firstSpan = newSpan;

            // only give the first span the id
            record.firstSpan.id = id;
        }

        if (record.lastSpan) {
            record.lastSpan.nextSpan = newSpan;
        }

        record.lastSpan = newSpan;

        // every span in the highlight has a reference to the first span
        newSpan.firstSpan = record.firstSpan;
        return newSpan;
    });

    // every span in the list must have a 'nextSpan' property, even if null.
    // Being an SPAN element, with this property defined, is a check for validity
    //        if (record.lastSpan) {
    //            record.lastSpan.nextSpan = null;
    //        }

    // terminate
    //        if (record.firstSpan) {
    //            record.lastSpan.nextElement = record; //connect linked list back to record
    //        }

    return record.firstSpan;
}


function _doCreate(range, record, createWrapper) {
    "use strict";
    //(startContainer == endContainer && startOffset == endOffset)
    if (range.collapsed) {
        return;
    }

    var startSide = range.startContainer,
        endSide = range.endContainer,
        ancestor = range.commonAncestorContainer,
        dirIsLeaf = true;

    if (range.endOffset === 0) { //nodeValue = text | element
        while (!endSide.previousSibling && endSide.parentNode !== ancestor) {
            endSide = endSide.parentNode;
        }

        endSide = endSide.previousSibling;
    } else if (endSide.nodeType === Node.TEXT_NODE) {
        if (range.endOffset < endSide.nodeValue.length) {
            endSide.splitText(range.endOffset);
        }
    } else if (range.endOffset > 0) { //nodeValue = element
        endSide = endSide.childNodes.item(range.endOffset - 1);
    }

    if (startSide.nodeType === Node.TEXT_NODE) {
        if (range.startOffset === startSide.nodeValue.length) {
            dirIsLeaf = false;
        } else if (range.startOffset > 0) {
            startSide = startSide.splitText(range.startOffset);

            if (endSide === startSide.previousSibling) {
                endSide = startSide;
            }
        }
    } else if (range.startOffset < startSide.childNodes.length) {
        startSide = startSide.childNodes.item(range.startOffset);
    } else {
        dirIsLeaf = false;
    }

    range.setStart(range.startContainer, 0);
    range.setEnd(range.startContainer, 0);

    var done = false,
        node = startSide;

    do {
        if (dirIsLeaf && node.nodeType === Node.TEXT_NODE &&
            !(node.parentNode instanceof HTMLTableElement) &&
            !(node.parentNode instanceof HTMLTableRowElement) &&
            !(node.parentNode instanceof HTMLTableColElement) &&
            !(node.parentNode instanceof HTMLTableSectionElement)) {
            //
            var wrap = node.previousSibling;

            if (!wrap || wrap !== record.lastSpan) {
                wrap = createWrapper(node);
                node.parentNode.insertBefore(wrap, node);
            }

            wrap.appendChild(node);

            // remove transparent style to fade to colour desired by class
            //                window.setTimeout(function(elem) {
            //                    elem.style.removeProperty("background-color");
            //                    elem.style.removeProperty("color");
            //                    elem.style.removeProperty("-webkit-box-shadow");
            //                }, 0, wrap);

            node = wrap.lastChild;
            dirIsLeaf = false;
        }

        if (node === endSide && (!endSide.hasChildNodes() || !dirIsLeaf)) {
            done = true;
        }

        if (node instanceof HTMLScriptElement ||
            node instanceof HTMLStyleElement ||
            node instanceof HTMLSelectElement) {
            //never parse their children
            dirIsLeaf = false;
        }

        if (dirIsLeaf && node.hasChildNodes()) {
            node = node.firstChild;
        } else if (node.nextSibling !== null) {
            node = node.nextSibling;
            dirIsLeaf = true;
        } else if (node.nextSibling === null) {
            node = node.parentNode;
            dirIsLeaf = false;
        }
    } while (!done);
}




// scroll logic
function scrollIt(destination, duration = 200, easing = 'linear', callback) {


    const easings = {
        linear(t) {
            return t;
        },
        easeInQuad(t) {
            return t * t;
        },
        easeOutQuad(t) {
            return t * (2 - t);
        },
        easeInOutQuad(t) {
            return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        },
        easeInCubic(t) {
            return t * t * t;
        },
        easeOutCubic(t) {
            return (--t) * t * t + 1;
        },
        easeInOutCubic(t) {
            return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
        },
        easeInQuart(t) {
            return t * t * t * t;
        },
        easeOutQuart(t) {
            return 1 - (--t) * t * t * t;
        },
        easeInOutQuart(t) {
            return t < 0.5 ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t;
        },
        easeInQuint(t) {
            return t * t * t * t * t;
        },
        easeOutQuint(t) {
            return 1 + (--t) * t * t * t * t;
        },
        easeInOutQuint(t) {
            return t < 0.5 ? 16 * t * t * t * t * t : 1 + 16 * (--t) * t * t * t * t;
        }
    };

    const start = window.pageYOffset;
    const startTime = 'now' in window.performance ? performance.now() : new Date().getTime();

    const documentHeight = Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight);
    const windowHeight = window.innerHeight || document.documentElement.clientHeight || document.getElementsByTagName('body')[0].clientHeight;
    const destinationOffset = typeof destination === 'number' ? destination : destination.offsetTop;
    const destinationOffsetToScroll = Math.round(documentHeight - destinationOffset < windowHeight ? documentHeight - windowHeight : destinationOffset);

    if ('requestAnimationFrame' in window === false) {
        window.scroll(0, destinationOffsetToScroll);
        if (callback) {
            callback();
        }
        return;
    }


    function scroll() {
        const now = 'now' in window.performance ? performance.now() : new Date().getTime();
        const time = Math.min(1, ((now - startTime) / duration));
        const timeFunction = easings[easing](time);
        window.scroll(0, Math.ceil((timeFunction * (destinationOffsetToScroll - start)) + start));

        if (window.pageYOffset === destinationOffsetToScroll) {
            if (callback) {
                callback();
            }
            return;
        }

        requestAnimationFrame(scroll);
    }

    scroll();
}


