window.browser = (function () {
    return window.msBrowser ||
        window.browser ||
        window.chrome;
})();
console.log("Spike Background Script Recieved");




// Set storage properties
chrome.storage.sync.set({
    displayHighlights: null
}, function (data) {
    if (chrome.runtime.lastError) {
        console.error(
            "Error setting " + displayHighlights + " to " + JSON.stringify(data) +
            ": " + chrome.runtime.lastError.message
        );
    }
});






browser.runtime.onConnect.addListener(function (port) {
    console.log(JSON.stringify(port.name));
    switch (port.name) {
        case "checkUser":
            port.onMessage.addListener(function (msg) {
                chrome.storage.sync.get("userData", function (data) {
                    console.log(data.userData);
                })
            })
            port.postMessage({
                userData: "checked userdata"
            });
            break;
        case "authenTicateUser":
            port.onMessage.addListener(function (msg) {
                console.log(msg)
                chrome.storage.sync.set({
                    userData: msg.userData
                }, function () { // Default to empty array
                    if (chrome.runtime.lastError) {
                        console.error("Error setting UserData:" + userData + "adn UserNotes" + userNotes + " to " + JSON.stringify(data) +
                            ": " + chrome.runtime.lastError.message
                        );
                    }
                });

            });


            port.postMessage({
                userData: "User Authenticated"
            });

            break;

        case "getUserNotes":
            port.onMessage.addListener(function (msg) {
                console.log(msg);

                chrome.storage.local.set({
                    userNotes: msg.userNotes
                }, function () { // Default to empty array
                    if (chrome.runtime.lastError) {
                        console.error("Error setting  UserNotes" + userNotes + " to " + JSON.stringify(data) +
                            ": " + chrome.runtime.lastError.message
                        );
                    }
                });
                chrome.storage.local.get('userNotes', function (userNotes) {
                    console.log(userNotes);
                })
                port.postMessage({
                    userotes: "Get User Notes Succesfull"
                });

            });
            break;
        case "logoutUser":
            port.onMessage.addListener(function (msg) {
                chrome.storage.sync.set({
                    userData: msg.userData
                }, function () {
                    if (chrome.runtime.lastError) {
                        console.error(
                            "Error setting " + userNotes + " to " + JSON.stringify(data) +
                            ": " + chrome.runtime.lastError.message
                        );
                    }
                });
                chrome.storage.local.set({
                    userNotes: msg.userNotes
                }, function () {
                    if (chrome.runtime.lastError) {
                        console.error(
                            "Error setting " + userNotes + " to " + JSON.stringify(data) +
                            ": " + chrome.runtime.lastError.message
                        );
                    }
                });
                chrome.storage.local.get('userNotes', function (userNotes) {
                    console.log(userNotes);
                });
                chrome.storage.sync.get('userData', function (userNotes) {
                    console.log(userNotes);
                })
                port.postMessage({
                    user: "User successfully logged out"
                });

            });
            break;
        case "pushHighlight":
            port.onMessage.addListener(function (msg) {

                chrome.storage.sync.get("displayHighlights", function (data) {

                    if (data.displayHighlights === null || data.displayHighlights.length === 0) {
                        chrome.storage.sync.set({
                            displayHighlights: msg.displayHighlights
                        }, function () {
                            if (chrome.runtime.lastError) {
                                console.error(
                                    "Error setting " + displayHighlights + " to " + JSON.stringify(data) +
                                    ": " + chrome.runtime.lastError.message
                                );
                            }
                        });
                    } else if (data.displayHighlights.length >= 1) {
                        Array.prototype.push.apply(data.displayHighlights, msg.displayHighlights);
                        console.log(data.displayHighlights);
                        chrome.storage.sync.set({
                            displayHighlights: data.displayHighlights
                        }, function () {
                            if (chrome.runtime.lastError) {
                                console.error(
                                    "Error setting " + displayHighlights + " to " + JSON.stringify(data) +
                                    ": " + chrome.runtime.lastError.message
                                );
                            }
                        });
                    }
                });
                chrome.storage.sync.get('displayHighlights', function (data) {
                    console.log(data.displayHighlights);
                })

            });
            port.postMessage({
                displayHighlights: "Highlights added"
            });

            break;
        case "cleanNotes":
            port.onMessage.addListener(function (msg) {
                chrome.storage.sync.get("displayHighlights", function (data) {
                    var url = msg.cleanNotes[0].url;
                    console.log(data);
                    console.log(url);
                    var newHighlights = data.displayHighlights.filter((ele) => {
                        if (ele.url !== url) {
                            return ele
                        }
                    })
                    chrome.storage.sync.set({
                        displayHighlights: newHighlights
                    })
                })
            });
            port.postMessage({
                displayHighlights: "Highlights successfully cleaned"
            });

            break;
        case "displayOnPage":
            port.onMessage.addListener(function (msg) {
                chrome.tabs.query({
                    active: true,
                    currentWindow: true
                }, function (tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        displayMessage: msg
                    });
                });
            });
            port.postMessage({
                displayOnPage: "Highlights displayed"
            });

            break;

        case "scrollToId":
            port.onMessage.addListener(function (msg) {
                chrome.tabs.query({
                    active: true,
                    currentWindow: true
                }, function (tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        scrollToId: msg
                    });
                })
            });
            port.postMessage({
                scrollToId: "Scrolled to Element"
            });
            break;
        case "getUrlTime":
            port.onMessage.addListener(function (msg) {
                console.log(msg);
                chrome.tabs.query({
                    active: true,
                    currentWindow: true
                }, function (tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        tabs: tabs,
                        message: msg
                    });
                })
            });
            port.postMessage({
                getUrlTime: "url time"
            });

        default:
            break;
    }


});



browser.browserAction.onClicked.addListener(function (tab) {
    console.log("clicked popup");
    browser.tabs.executeScript({
        code: "console.log('background script')"
    });
    browser.tabs.executeScript(null, {
        file: "spike.client.js"
    });
});