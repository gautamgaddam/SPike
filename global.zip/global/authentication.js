$(document).ready(function(){

document.getElementById('noteCancel').addEventListener('click', noteCancel);
document.getElementById('userSignIn').addEventListener('click', userSignIn);
document.getElementById('goToSignIn').addEventListener('click', goToLogin);
document.getElementById('logout').addEventListener('click', logout);
// document.getElementById('gotoRegister').addEventListener('click', gotoRegister);
// document.getElementById('registerUser').addEventListener('click', registerUser);

function userSignIn(e){
    e.preventDefault();
    var obj={};
    obj.email= $("#emailUser").val();
    obj.password= $("#passUser").val();
    httpCall("http://10.10.73.9:8012/api/authenticate", {email: obj.email, password: obj.password}).done(function(data){
    if(data){
        
        console.log(data);


            var port = chrome.runtime.connect({ name: "authenTicateUser" });
            port.postMessage({ userData: data });
            let div= document.createElement('div');
            div.innerHTML= "User id:"+data.userid;
            div.setAttribute("id","userName");
          document.getElementById("userLogin").classList.add("dis-none");
          document.getElementById("notesDiv").classList.remove("dis-none");
          document.getElementById("goToSignIn").classList.add("dis-none");
          document.getElementById("showUser").appendChild(div);
          document.getElementById("logout").classList.remove("dis-none");
    }


    })
  
    

}
function noteCancel(e){
    e.preventDefault();
    document.getElementById("userLogin").classList.add("dis-none");
    document.getElementById("notesDiv").classList.remove("dis-none");
    document.getElementById("goToSignIn").classList.remove("dis-none");
}





function goToLogin(){
    document.getElementById("goToSignIn").classList.add("dis-none");
    document.getElementById('userLogin').classList.remove('dis-none');
    document.getElementById('notesDiv').classList.add('dis-none');
}


function logout(e){
    e.preventDefault();
    var port = chrome.runtime.connect({ name: "logoutUser" });
    port.postMessage({ userData: null });
    document.getElementById("logout").classList.add("dis-none");
    document.getElementById("userName").remove();
    document.getElementById("goToSignIn").classList.remove("dis-none");
}


function httpCall(url, postData = {}, asyncCall = true, headers = {}, type = "POST") {
    return $.ajax({
        type: type,
        url: url,
        headers: headers,
        async: asyncCall,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify(postData)
    });
}

})